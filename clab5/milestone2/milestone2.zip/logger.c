#include "logger.h"

int write_to_log_process(char *msg){
    //TODO
    return 0;
};

int create_log_process() {
    //TODO
    return 0;
};

int end_log_process() {
    //TODO
    return 0;
};