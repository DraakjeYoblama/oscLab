//
// Created by douwe on 3/12/23.
//

#ifndef CLAB7_MAIN_H
#define CLAB7_MAIN_H

#endif //CLAB7_MAIN_H

int main();
void *reader();