#ifndef CLAB7_MAIN_H
#define CLAB7_MAIN_H

#include "sbuffer.h"

int main();
void *reader(void* buffer);


#endif //CLAB7_MAIN_H

